/*
#####################
# MoHieDDiNNe Codes #
#####################
*/

#pragma once
#include <stdio.h>
#include <windows.h>

